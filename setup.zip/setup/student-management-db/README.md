# Student Management Database

The chosen DBMS is MySQL, and the utility is adminer.

We are using 2 containers:
1. `studentpubdb` for connecting with backend;
2. `studentpubdbutility` for using the utility.

## Istructions
From the root folder of the project, run the following commands:
1.  `docker-compose up`

This command starts the database and database utility management containers.
It initialize the database and creates a persistent volume for the database and 2 networks: one for database and database utility management (`studentpub-network-utility`) and another for the database and backend (`studentpub-network-api`).

2. `docker-compose down` shuts down the database and the utility management tool.

3. `docker-compose down -v` shuts down the database and the utility management tool and deletes the persistent volume and networks.

## Connecting to the database
For connecting with backend.

### Method 1
You can use localhost with port 3306.

### Method 2
If you have a container in the same netrwork as `studentpub-network-api` you can connect using the container name `studentpubdb` with port 3306.

## Connecting to the utility management
You can use localhost with port 8081 to use the management utility (adminer).
For the server we use `studentpubdb` ad for the database `studentpubusers`.

## Credidentials
All the credidentials used to create and connect to the database can be found in the `.env` file.