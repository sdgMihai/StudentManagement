-- Adminer 4.8.0 MySQL 5.7.33 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `studentpubusers`;
CREATE DATABASE `studentpubusers` ;
USE `studentpubusers`;

DROP TABLE IF EXISTS `user_type`;
CREATE TABLE `user_type` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `type` varchar(15) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `login` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `first_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `last_name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `type` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`type`) REFERENCES `user_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `admins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `class`;
CREATE TABLE `class` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `credit_points` tinyint(4) NOT NULL,
  `type` enum('Optional','Obligatoriu','Alegere') COLLATE utf8mb4_bin NOT NULL,
  `year` tinyint(4) NOT NULL,
  `semester` tinyint(4) NOT NULL,
  `major_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `major_id` (`major_id`),
  CONSTRAINT `class_ibfk_1` FOREIGN KEY (`major_id`) REFERENCES `majors` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `faculty`;
CREATE TABLE `faculty` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

DROP TABLE IF EXISTS `majors`;
CREATE TABLE `majors` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `faculty` bigint(20) NOT NULL,
  PRIMARY KEY (`id`), 
  KEY `faculty` (`faculty`),
  CONSTRAINT `majors_ibfk_1` FOREIGN KEY (`faculty`) REFERENCES `faculty` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `seria`;
CREATE TABLE `seria` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(2) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `grupa`;
CREATE TABLE `grupa` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `seria` bigint(20) NOT NULL,
  `number` INT NOT NULL,
  `major` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `seria` (`seria`),
  CONSTRAINT `grupa_ibfk_1` FOREIGN KEY (`seria`) REFERENCES `seria` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grupa_ibfk_2` FOREIGN KEY (`major`) REFERENCES `majors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `secretary`;
CREATE TABLE `secretary` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `faculty` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `faculty` (`faculty`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `secretary_ibfk_2` FOREIGN KEY (`faculty`) REFERENCES `faculty` (`id`) ON DELETE CASCADE,
  CONSTRAINT `secretary_ibfk_23` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  -- `student_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `student_identification_number` bigint(20) NOT NULL,
  `father_initial` varchar(10) COLLATE utf8mb4_bin NOT NULL,
  `cnp` bigint(20) NOT NULL,
  -- `faculty_id` bigint(20) NOT NULL,  -- not in java app
  -- `major` bigint(20) NOT NULL,  -- not in java app
  `grupa` bigint(20) NOT NULL,
  PRIMARY KEY (`student_identification_number`),
  KEY `user_id` (`user_id`),
  -- KEY `faculty_id` (`faculty_id`),
  -- KEY `major` (`major`),
  KEY `grupa` (`grupa`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  -- CONSTRAINT `student_ibfk_2` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`) ON DELETE CASCADE,
  -- CONSTRAINT `student_ibfk_3` FOREIGN KEY (`major`) REFERENCES `majors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_ibfk_4` FOREIGN KEY (`grupa`) REFERENCES `grupa` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

DROP TABLE IF EXISTS `grades`;
CREATE TABLE `grades` (
  `class_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `student_identification_number` bigint(20) NOT NULL,
  `grade` int(11) NOT NULL,
  PRIMARY KEY (`class_id`, `student_identification_number`),
  KEY `student_identification_number` (`student_identification_number`),
  CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`student_identification_number`) REFERENCES `student` (`student_identification_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


insert into user_type(type) values ('USER');

insert into user(login, password, first_name, last_name, email, phone_number, type)
values ('user', 'user', 'user', 'user', 'user@user.com', 243231470, 1);

insert into admin(id, user_id)
values (1, 1);

insert into faculty(id, name)
values (1, "test");

insert into majors(id, name, faculty)
values (1, "test", 1);

insert into class(id, name, credit_points, type, year, semester, major_id)
values (1, "test" , 1, "Obligatoriu", 1, 1, 1);

insert into grades(class_id, student_identification_number, grade)
values (1, 1, 1);

insert into seria(id, name)
values (1, "t");

insert into grupa(id, number, major, seria)
values (1, 1, 1, 1);

insert into student(student_identification_number, cnp, father_initial, grupa, user_id)
values(1, 1, "t", 1, 1);

insert into secretary(id, faculty, user_id)
values(1, 1, 1);

-- 2021-04-23 10:53:06


