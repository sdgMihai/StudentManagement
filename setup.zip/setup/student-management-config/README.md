## Student Management Config #

#### Note: #
For distributed running, move kong-stack.yml and portrainer-stack.yml to root project first.

