package com.studentmanagement.studentmanagementauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagementAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
