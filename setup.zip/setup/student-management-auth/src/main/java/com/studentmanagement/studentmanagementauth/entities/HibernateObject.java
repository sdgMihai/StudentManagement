package com.studentmanagement.studentmanagementauth.entities;

public interface HibernateObject {

    Long getId();
    void setId(Long id);
}
